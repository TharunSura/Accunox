#!/usr/bin/env python3
import psutil
import os

# Define thresholds
CPU_THRESHOLD = 80  # in percentage
MEMORY_THRESHOLD = 80  # in percentage
DISK_THRESHOLD = 80  # in percentage

def check_cpu():
    cpu_usage = psutil.cpu_percent(interval=1)
    if cpu_usage > CPU_THRESHOLD:
        print(f"Alert! CPU usage is high: {cpu_usage}%")

def check_memory():
    memory = psutil.virtual_memory()
    memory_usage = memory.percent
    if memory_usage > MEMORY_THRESHOLD:
        print(f"Alert! Memory usage is high: {memory_usage}%")

def check_disk():
    disk = psutil.disk_usage('/')
    disk_usage = disk.percent
    if disk_usage > DISK_THRESHOLD:
        print(f"Alert! Disk usage is high: {disk_usage}%")

def main():
    print("Checking system health...")
    check_cpu()
    check_memory()
    check_disk()
    print("Health check complete.")

if __name__ == "__main__":
    main()
