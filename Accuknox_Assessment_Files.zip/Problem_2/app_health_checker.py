#!/usr/bin/env python3
import requests

APP_URL = "http://your-application-url.com"

def check_application_health():
    try:
        response = requests.get(APP_URL)
        if response.status_code == 200:
            print("Application is up and running!")
        else:
            print(f"Application is down. Status code: {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"Error: Unable to reach the application. {e}")

if __name__ == "__main__":
    check_application_health()
